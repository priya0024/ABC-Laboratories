package com.example.backendb.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AppoinmentDTO {
    private Long id;
    private BigDecimal fee;
    private String appointmentDateTime;
    private long patientId;
    private long docId;
}
