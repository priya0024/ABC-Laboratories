package com.example.backendb.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;
import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data

public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long patientID;
    private String fullName;
    private int age;
    private String contactNumber;

    @OneToMany(mappedBy = "id", cascade = CascadeType.ALL)
    private List<Appointment> appointmentList;
}

