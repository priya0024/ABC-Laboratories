package com.example.backendb.service;

import com.example.backendb.entity.Appointment;
import com.example.backendb.repository.AppointmentRepository;
import com.example.backendb.dto.AppoinmentDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    public Appointment getAppointmentById(Long id) {
        return appointmentRepository.findById(id).orElse(null);
    }


    public List<AppoinmentDTO> getAppointments() {
        return appointmentRepository.findAll().stream()
                .map(appointment -> new AppoinmentDTO(
                        appointment.getId(),
                        appointment.getFee(),
                        appointment.getAppointmentDateTime()+"",
                        appointment.getPatientId().getPatientID(),
                        appointment.getDocId().getDocId()
                ))
                .collect(Collectors.toList());
    }


    public Appointment createAppointment(Appointment appointment) {
        return appointmentRepository.save(appointment);
    }

    public Appointment updateAppointment(Appointment appointment) {
        Appointment existingAppointment = appointmentRepository.findById(appointment.getId()).orElse(null);
        if (existingAppointment != null) {
            existingAppointment.setPatientId(appointment.getPatientId());
            existingAppointment.setDocId(appointment.getDocId());
            existingAppointment.setAppointmentDateTime(appointment.getAppointmentDateTime());
            existingAppointment.setFee(appointment.getFee());
            return appointmentRepository.save(existingAppointment);
        }
        return null;
    }

    public String deleteAppointment(Long id) {
        appointmentRepository.deleteById(id);
        return "Appointment Removed!! " + id;
    }
}

