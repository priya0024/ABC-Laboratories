package com.example.backendb.service;

import com.example.backendb.entity.Patient;
import com.example.backendb.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;


    public Patient savePatient(Patient patient) {
        return patientRepository.save(patient);
    }

    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    public Patient getPatientById(Long id) {
        return patientRepository.findById(id).orElse(null);
    }

    public Patient updatePatient(Patient patient) {
        Patient existingPatient = patientRepository.findById(patient.getPatientID()).orElse(null);
        if (existingPatient != null) {
            existingPatient.setFullName(patient.getFullName());
            existingPatient.setAge(patient.getAge());
            existingPatient.setContactNumber(patient.getContactNumber());
            return patientRepository.save(existingPatient);
        }
        return null;

    }

    public String deletePatient(Long id) {
        patientRepository.deleteById(id);
        return "Patient Removed!! " + id;
    }
}
