package com.example.backendb.service;

import com.example.backendb.entity.User;
import com.example.backendb.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User getUserByUserNameAndPw(String userName, String password) {
        return userRepository.findByUsernameAndPasswordAndRole(userName, password, "Admin");
    }

}
