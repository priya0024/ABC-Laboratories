package com.example.backendb.repository;

import com.example.backendb.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User,Long> {
    User findByUsernameAndPasswordAndRole(String userName, String password, String role);
}
