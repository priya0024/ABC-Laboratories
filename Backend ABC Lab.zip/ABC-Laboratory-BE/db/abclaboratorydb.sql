CREATE DATABASE abc_laboratory;

USE abc_laboratory;
INSERT INTO user VALUES ('1','Admin','Admin','Admin');
