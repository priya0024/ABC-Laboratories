$('#btnLogin').click(function () {
    let loginUserName = $('#txtUserName').val();
    let loginPassword = $('#txtPassword').val();

    var jsonData = {
        "id": 1,
        "username": loginUserName,
        "password": loginPassword,
        "role": 'Admin'
    };

    $.ajax({
        method: "POST",
        url: "http://localhost:9090/api/v1/login",
        contentType: "application/json",
        data: JSON.stringify(jsonData),
        success: function (res) {
            if (res.data === null) {
                alert('Login Fail!')
            } else {
                alert('Login Success!')
                window.location.href = "../pages/admin.html";
            }
        },
        error: function (xhr, textStatus, errorThrown) {
            console.error("Error:", xhr, textStatus);
        }
    });
});


