// ================================================================================================================ MAIN
$('#btnAppointment').click(function () {
    $('#AppointmentPage').css({
        'display': 'block'
    });
    $('#DoctorPage').css({
        'display': 'none'
    });
    $('#PatientPage').css({
        'display': 'none'
    });
});
$('#btnDoctor').click(function () {
    $('#AppointmentPage').css({
        'display': 'none'
    });
    $('#DoctorPage').css({
        'display': 'block'
    });
    $('#PatientPage').css({
        'display': 'none'
    });
});
$('#btnPatient').click(function () {
    $('#AppointmentPage').css({
        'display': 'none'
    });
    $('#DoctorPage').css({
        'display': 'none'
    });
    $('#PatientPage').css({
        'display': 'block'
    });
});
// ================================================================================================================ MAIN

// =============================================================================================== Appointment Functions
loadAppointments();
function clearAppointmentFields() {
    $('#apID').val(null);
    $('#apFee').val("");
    $('#apDateTime').val("");
    $('#apPatientId').val("");
    $('#apDoctorId').val("");
}
$('#btnAppointmentUpdate').click(function () {
    updateAppointment();
    loadAppointments();
    clearAppointmentFields();
})
$('#btnAppointmentSave').click(function () {

    let apID = $('#apID').val();
    let apFee = $('#apFee').val();
    let apDateTime = $('#apDateTime').val();
    let apDoctorId = $('#apDoctorId').val();
    let apPatientId = $('#apPatientId').val();

    $.ajax({
        method: "POST",
        url: "http://localhost:9090/api/v1/appointment",
        dataType: 'Json',
        async: true,
        contentType: "application/json",
        data: JSON.stringify({
            "id": apID,
            "fee": apFee,
            "appointmentDateTime": apDateTime,
            "patientId": apPatientId,
            "docId": apDoctorId
        }),
        success: function (res) {
            console.log("res ======== ", res)
            loadAppointments();
            clearAppointmentFields();
        },
        error: function (ob, textStatus, error) {
        }
    });
});
$('#btnAppointmentDelete').click(function () {
    let apID = $('#apID').val();

    if (apID !== "") {
        $.ajax({
            method: "delete",
            url: 'http://localhost:9090/api/v1/appointment/delete/' + apID,
            async: true,
            success: function (response) {
                loadAppointments();
                clearAppointmentFields();
            },
            error: function (response) {
            }
        });
    }
});
function loadAppointments() {
    $('#tblAppointmentBody').empty();
    $.ajax({
        url: 'http://localhost:9090/api/v1/appointment',
        method: 'GET',
        async: false,
        dataType: 'json',
        success: function (res) {
            for (let i = 0; i < res.length; i++) {
                let appointment = res[i];
                let id = appointment.id;
                let fee = appointment.fee;
                let datetime = appointment.appointmentDateTime;
                let patientId = appointment.patientId;
                let docId = appointment.docId;

                $('#tblAppointmentBody').append(`<tr><td>${id}</td><td>${fee}</td><td>${datetime}</td><td>${patientId}</td><td>${docId}</td></tr>`);
            }
        }
    });
}

function updateAppointment() {

    let apID = $('#apID').val();
    let apFee = $('#apFee').val();
    let apDateTime = $('#apDateTime').val();
    let apDoctorId = $('#apDoctorId').val();
    let apPatientId = $('#apPatientId').val();

    $.ajax({
        method: "PUT",
        url: `http://localhost:9090/api/v1/appointment/update/${apID}`,
        contentType: "application/json",
        async: false,
        data: JSON.stringify(
            {
                "id": apID,
                "fee": apFee,
                "appointmentDateTime": apDateTime,
                "patientId": apPatientId,
                "docId": apDoctorId
            }
        ),
        success: function (data) {
            return true;
        }
    });
}
// =============================================================================================== Appointment Functions

// =================================================================================================== Patient Functions
loadPatients();
function clearPatientsFields() {
    $('#paId').val(null);
    $('#age').val("");
    $('#fullName').val("");
    $('#contactNumber').val("");
}
$('#btnPatientSave').click(function () {

    let paId = $('#paId').val();
    let paName = $('#fullName').val();
    let paAge = $('#age').val();
    let paContactNumber = $('#contactNumber').val();

    $.ajax({
        method: "POST",
        url: "http://localhost:9090/api/v1/patient/add",
        dataType: 'Json',
        async: true,
        contentType: "application/json",
        data: JSON.stringify({
            "patientID": paId,
            "fullName": paName,
            "age": paAge,
            "contactNumber": paContactNumber
        }),
        success: function (res) {
            loadPatients();
            clearPatientsFields();
        },
        error: function (ob, textStatus, error) {
        }
    });
});
$('#btnPatientDelete').click(function () {
    let paID = $('#paId').val();

    if (paID !== "") {
        $.ajax({
            method: "delete",
            url: 'http://localhost:9090/api/v1/patient/delete/' + paID,
            async: true,
            success: function (response) {
                loadPatients();
                clearPatientsFields();
            },
            error: function (response) {
            }
        });
    }
});
$('#btnPatientUpdate').click(function () {
    updatePatient();
    loadPatients();
    clearPatientsFields();
})
function loadPatients() {
    $('#tblPatientBody').empty();
    $.ajax({
        url: 'http://localhost:9090/api/v1/patient',
        method: 'GET',
        async: false,
        dataType: 'json',
        success: function (res) {
            console.log("res ", res)
            let values = res.data;
            for (i in values) {
                let id = values[i].patientID;
                let age = values[i].age;
                let contactNumber = values[i].contactNumber;
                let fullName = values[i].fullName;

                $('#tblPatientBody').append(`<tr><td>${id}</td><td>${fullName}</td><td>${age}</td><td>${contactNumber}</td></tr>`)
            }
        }
    });
}
function updatePatient() {

    let paId = $('#paId').val();
    let paName = $('#fullName').val();
    let paAge = $('#age').val();
    let paContactNumber = $('#contactNumber').val();

    $.ajax({
        method: "PUT",
        url: `http://localhost:9090/api/v1/patient/update`,
        contentType: "application/json",
        async: false,
        data: JSON.stringify(
            {
                "patientID": paId,
                "fullName": paName,
                "age": paAge,
                "contactNumber": paContactNumber
            }
        ),
        success: function (data) {
            return true;
        }
    });
}
// =================================================================================================== Patient Functions


// ==================================================================================================== Doctor Functions
loadDoctors();
function clearDoctorFields() {
    $('#docId').val(null);
    $('#docEmail').val("");
    $('#docName').val("");
    $('#docContactNumber').val("");
    $('#docSpecializedField').val("");
}
$('#btnDoctorSave').click(function () {

    let docId = $('#docId').val();
    let docName = $('#docName').val();
    let docEmail = $('#docEmail').val();
    let docContactNumber = $('#docContactNumber').val();
    let docSpecial = $('#docSpecializedField').val();

    $.ajax({
        method: "POST",
        url: "http://localhost:9090/api/v1/doctor/add",
        dataType: 'Json',
        async: true,
        contentType: "application/json",
        data: JSON.stringify({
            "docId": docId,
            "name": docName,
            "email":docEmail,
            "contactNumber": docContactNumber,
            "specializedField": docSpecial
        }),
        success: function (res) {
            loadDoctors();
            clearDoctorFields();
        },
        error: function (ob, textStatus, error) {
        }
    });
});
$('#btnDoctorDelete').click(function () {
    let docId = $('#docId').val();

    if (docId !== "") {
        $.ajax({
            method: "delete",
            url: 'http://localhost:9090/api/v1/doctor/delete/' + docId,
            async: true,
            success: function (response) {
                loadDoctors();
                clearDoctorFields();
            },
            error: function (response) {
            }
        });
    }
});
$('#btnDoctorUpdate').click(function () {
    updateDoctor();
    loadDoctors();
    clearDoctorFields();
})
function loadDoctors() {
    $('#tblDoctorBody').empty();
    $.ajax({
        url: 'http://localhost:9090/api/v1/doctor',
        method: 'GET',
        async: false,
        dataType: 'json',
        success: function (res) {
            console.log("res ", res)
            let values = res.data;
            for (i in values) {
                let docId = values[i].docId;
                let docName = values[i].name;
                let docEmail = values[i].email;
                let docContactNumber = values[i].contactNumber;
                let docSpec = values[i].specializedField;

                $('#tblDoctorBody').append(`<tr><td>${docId}</td><td>${docContactNumber}</td><td>${docName}</td><td>${docEmail}</td><td>${docSpec}</td></tr>`)
            }
        }
    });
}
function updateDoctor() {

    let docId = $('#docId').val();
    let docName = $('#docName').val();
    let docEmail = $('#docEmail').val();
    let docContactNumber = $('#docContactNumber').val();
    let docSpecial = $('#docSpecializedField').val();

    $.ajax({
        method: "PUT",
        url: `http://localhost:9090/api/v1/doctor/update`,
        contentType: "application/json",
        async: false,
        data: JSON.stringify(
            {
                "docId": docId,
                "name": docName,
                "email":docEmail,
                "contactNumber": docContactNumber,
                "specializedField": docSpecial
            }
        ),
        success: function (data) {
            return true;
        }
    });
}
// ==================================================================================================== Doctor Functions
